import type { Config } from "tailwindcss";

export default {
  content: ["./index.html", "./warehouse/**/*.html", "./employee/**/*.html", "./map/**/*.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        maroon: { DEFAULT: "#6B1A2C", dark: "#4E1220", light: "#8A2A40", tint: "#F4E8EB" },
        gold: { DEFAULT: "#C9A84C", light: "#E6D39A" },
        ink: "#2B2B2B",
        surface: "#F2F2F2",
        dept: {
          "hvac-service": "#D32F2F",
          "hvac-service-light": "#EF9A9A",
          "hvac-install": "#8E1B1B",
          "hvac-install-deep": "#5C0F0F",
          "hvac-nc": "#E65100",
          "plumb-service": "#1E88E5",
          "plumb-service-light": "#90CAF9",
          "plumb-install": "#1A237E",
          "plumb-install-deep": "#0D1450",
        },
      },
      fontFamily: {
        sans: ["system-ui", "-apple-system", "Segoe UI", "Roboto", "Helvetica", "Arial", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
