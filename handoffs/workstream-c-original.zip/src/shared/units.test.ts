import { describe, expect, it } from "vitest";
import {
  formatFtIn,
  formatIn,
  frontDir,
  mapToSheet,
  mapToShelf,
  parseLength,
  placementFromCenter,
  recalcClearHeights,
  rotationForFront,
  shelfCenter,
  shelfCorners,
  shelfToMap,
  sheetToMap,
  slotRect,
  evenRows,
} from "./units";
import { DEMO_SHELVES } from "./mock/demo-data";

const close = (a: number, b: number) => expect(a).toBeCloseTo(b, 6);

describe("parseLength", () => {
  it.each([
    ["40'-3\"", "ft", 483],
    ["40' 3", "ft", 483],
    ["40-3", "ft", 483],
    ["40 3", "ft", 483],
    ["40.25'", "ft", 483],
    ['483"', "ft", 483],
    ["483", "in", 483],
    ["40", "ft", 480],
    ["7'-8 1/2\"", "in", 92.5],
    ["8 1/2\"", "ft", 8.5],
    ["8 1/2", "in", 8.5],
    ["1/2\"", "in", 0.5],
    ["162'-3\"", "ft", 1947],
    ["-2'-6\"", "ft", -30],
    ["  12'  ", "in", 144],
  ] as const)("%s (%s field) = %d in", (s, unit, want) => {
    expect(parseLength(s, unit)).toBe(want);
  });
  it("rejects junk", () => {
    expect(parseLength("abc")).toBeNull();
    expect(parseLength("")).toBeNull();
    expect(parseLength("4'x")).toBeNull();
  });
  it("rounds to 1/16 in", () => {
    expect(parseLength("1.04")).toBe(1.0625);
  });
});

describe("formatFtIn", () => {
  it.each([
    [483, "40'-3\""],
    [92.5, "7'-8 1/2\""],
    [1947, "162'-3\""],
    [12, "1'-0\""],
    [6.5, "6 1/2\""],
    [0, '0"'],
    [-30, "-2'-6\""],
    [0.125, '1/8"'],
    [10.0625, '10 1/8"'], // 1/16 rounds to nearest 1/8 for display
  ])("%d -> %s", (n, s) => {
    expect(formatFtIn(n)).toBe(s);
  });
  it("round-trips through parseLength", () => {
    for (const n of [0.5, 7.25, 96, 483, 1203, 1947, 13.875]) expect(parseLength(formatFtIn(n), "in")).toBe(n);
  });
  it("formatIn never converts to feet", () => {
    expect(formatIn(15)).toBe('15"');
    expect(formatIn(30.5)).toBe('30 1/2"');
  });
});

describe("survey sheet <-> map", () => {
  it("sheet (0,0) = map (0,1947)", () => {
    expect(sheetToMap({ x: 0, y: 0 })).toEqual({ x: 0, y: 1947 });
  });
  it("map origin = sheet (0,1947)", () => {
    expect(mapToSheet({ x: 0, y: 0 })).toEqual({ x: 0, y: 1947 });
  });
  it("STORAGE - FILTERS 120 north edge (map Y 1683) is sheet Y 264 (22')", () => {
    expect(mapToSheet({ x: 100, y: 1683 })).toEqual({ x: 100, y: 264 });
  });
  it("is its own inverse", () => {
    const p = { x: 123.5, y: 777.25 };
    expect(sheetToMap(mapToSheet(p))).toEqual(p);
  });
});

describe("shelf (u,v) -> map", () => {
  const base = { x_in: 100, y_in: 200, width_in: 96, depth_in: 24 };
  it("rotation 0: front faces south, width runs east, back is north", () => {
    const s = { ...base, rotation_deg: 0 };
    expect(shelfToMap(s, 96, 0)).toEqual({ x: 196, y: 200 });
    expect(shelfToMap(s, 0, 24)).toEqual({ x: 100, y: 176 });
    expect(frontDir(0)).toEqual({ x: 0, y: 1 });
  });
  it("rotation 90: front faces west, width runs south", () => {
    const s = { ...base, rotation_deg: 90 };
    expect(shelfToMap(s, 96, 0)).toEqual({ x: 100, y: 296 });
    expect(shelfToMap(s, 0, 24)).toEqual({ x: 124, y: 200 });
    expect(frontDir(90)).toEqual({ x: -1, y: 0 });
  });
  it("rotation 180: front faces north, width runs west", () => {
    const s = { ...base, rotation_deg: 180 };
    expect(shelfToMap(s, 96, 0)).toEqual({ x: 4, y: 200 });
    expect(shelfToMap(s, 0, 24)).toEqual({ x: 100, y: 224 });
  });
  it("rotation 270: front faces east, width runs north", () => {
    const s = { ...base, rotation_deg: 270 };
    expect(shelfToMap(s, 96, 0)).toEqual({ x: 100, y: 104 });
    expect(shelfToMap(s, 0, 24)).toEqual({ x: 76, y: 200 });
    expect(frontDir(270)).toEqual({ x: 1, y: 0 });
  });
  it("free angle (30°) round-trips", () => {
    const s = { ...base, rotation_deg: 30 };
    const p = shelfToMap(s, 40, 10);
    close(p.x, 100 + 40 * Math.cos(Math.PI / 6) + 10 * Math.sin(Math.PI / 6));
    close(p.y, 200 + 40 * Math.sin(Math.PI / 6) - 10 * Math.cos(Math.PI / 6));
    const back = mapToShelf(s, p.x, p.y);
    close(back.u, 40);
    close(back.v, 10);
  });
  it("rotationForFront inverts frontDir", () => {
    for (const r of [0, 15, 90, 135, 180, 270, 315]) {
      const f = frontDir(r);
      expect(rotationForFront(f.x, f.y)).toBeCloseTo(r, 3);
    }
  });
  it("placementFromCenter puts the centre where asked", () => {
    for (const r of [0, 90, 180, 270, 33]) {
      const p = placementFromCenter(300, 400, r, 96, 24);
      const c = shelfCenter({ ...p, rotation_deg: r, width_in: 96, depth_in: 24 });
      expect(c.x).toBeCloseTo(300, 1);
      expect(c.y).toBeCloseTo(400, 1);
    }
  });
});

describe("demo shelves (contract §9)", () => {
  const byName = Object.fromEntries(DEMO_SHELVES.map((s) => [s.name, s]));
  it("A1 stands against the warehouse west wall facing east", () => {
    const a1 = byName.A1;
    const xs = shelfCorners(a1).map((p) => p[0]);
    expect(Math.min(...xs)).toBe(0); // back on the wall at X = 0
    expect(frontDir(a1.rotation_deg).x).toBe(1); // faces east
  });
  it("B1 stands against 121's south wall (Y 1683) facing north", () => {
    const ys = shelfCorners(byName.B1).map((p) => p[1]);
    expect(Math.max(...ys)).toBe(1675); // 8" off the wall line in the made-up demo position
    expect(frontDir(byName.B1.rotation_deg).y).toBe(-1);
  });
  it("F1 stands against 120's east wall (X 479.5) facing west", () => {
    const xs = shelfCorners(byName.F1).map((p) => p[0]);
    expect(Math.max(...xs)).toBe(471.5);
    expect(frontDir(byName.F1.rotation_deg).x).toBe(-1);
  });
});

describe("slots and rows", () => {
  const shelf = { width_in: 96, cols: 12, rows: evenRows(5, 84) };
  it("evenRows matches the demo construction (G at 4\", clear 15\")", () => {
    expect(shelf.rows[0]).toEqual({ row_index: 0, row_label: "G", elevation_in: 4, clear_height_in: 15 });
    expect(shelf.rows[4].elevation_in + shelf.rows[4].clear_height_in).toBe(84);
  });
  it("slotRect follows contract §4", () => {
    expect(slotRect(shelf, { row_index: 0, col_start: 7, width_span: 2, height_span: 1 })).toEqual({ left: 48, width: 16, bottom: 4, height: 15 });
    expect(slotRect(shelf, { row_index: 0, col_start: 5, width_span: 3, height_span: 2 })).toEqual({ left: 32, width: 24, bottom: 4, height: 31 });
    expect(slotRect(shelf, { row_index: 4, col_start: 1, width_span: 1, height_span: 2 })).toBeNull();
  });
  it("recalcClearHeights uses the gap to the next deck", () => {
    const rows = recalcClearHeights(
      [
        { row_index: 0, row_label: "G", elevation_in: 4, clear_height_in: 0 },
        { row_index: 1, row_label: "1", elevation_in: 30, clear_height_in: 0 },
      ],
      84,
    );
    expect(rows.map((r) => r.clear_height_in)).toEqual([25, 54]);
  });
});
