// Shared Contract v2 — TypeScript types for every shape, error and endpoint.
// Lengths are inches (REAL, rounded to 1/16 in). Map coordinates: origin = NW corner of
// WAREHOUSE 126, X east, Y south. See README "How coordinates work".
//
// Additions beyond contract v2 are marked `// ADDITION (C)` and listed in the Sync notes.

export type Role = "viewer" | "editor" | "admin";

export interface Me {
  email: string;
  name: string;
  role: Role;
}

export type BinType = "bin" | "box" | "tote" | "loose" | "drawer";
export type ShelfKind = "shelving" | "pallet_rack" | "cabinet" | "bench" | "floor_area";
export type OpeningKind = "door" | "overhead" | "opening";
export type MoveMode = "move" | "add" | "swap" | "share";

export type Department =
  | "HVAC Service"
  | "HVAC Install"
  | "HVAC New Construction"
  | "Plumbing Service"
  | "Plumbing Install"
  | string;

export type Point = [number, number];

// ---------- Building ----------

export interface Zone {
  zone_id: string;
  name: string;
  room_no: string;
  polygon_in: Point[];
  open_edges: number[];
  wall_height_in: number | null;
  notes: string;
  verified: boolean;
  version: number;
}

export interface Opening {
  opening_id: string;
  kind: OpeningKind;
  tag: string;
  x1_in: number;
  y1_in: number;
  x2_in: number;
  y2_in: number;
  height_in: number;
  zone_id: string | null;
  notes: string;
  verified: boolean;
  version: number;
}

// ---------- Shelves, rows, slots ----------

export interface Row {
  row_index: number;
  row_label: string;
  elevation_in: number;
  clear_height_in: number;
}

export interface SlotPartRef {
  part_id: string;
  part_name: string;
  part_code: string;
  on_hand_qty: number;
  par_qty: number;
}

export interface SlotBase {
  slot_id: string;
  slot_no: number;
  location_code: string;
  row_index: number;
  col_start: number;
  width_span: number;
  height_span: number;
  bin_type: BinType;
  bin_width_in: number | null;
  bin_height_in: number | null;
  bin_depth_in: number | null;
  bin_color: string | null;
  version: number;
}

/** Slot as returned by GET /api/shelves/:id (full occupants). */
export interface Slot extends SlotBase {
  parts: SlotPartRef[];
}

/** Slot as returned inside GET /api/layout (summary instead of full parts). */
export interface LayoutSlot extends SlotBase {
  part_count: number;
  on_hand_total: number;
  par_total: number;
  low: boolean;
  part_ids: string[];
  departments: string[]; // ADDITION (C): for color-by department without a parts fetch
}

export interface ShelfBase {
  shelf_id: string;
  name: string;
  zone_id: string | null;
  zone_name: string | null;
  kind: ShelfKind;
  x_in: number;
  y_in: number;
  rotation_deg: number;
  width_in: number;
  depth_in: number;
  height_in: number;
  cols: number;
  rows: Row[];
  wall_ref: string | null;
  notes: string;
  version: number;
}

export interface Shelf extends ShelfBase {
  slots: Slot[];
}

export interface LayoutShelf extends ShelfBase {
  slots: LayoutSlot[];
}

export interface Layout {
  layout_version: string;
  zones: Zone[];
  openings: Opening[];
  shelves: LayoutShelf[];
}

// ---------- Parts and locations ----------

export interface CoLocatedPart {
  part_id: string;
  part_name: string;
}

export interface Location {
  slot_id: string;
  location_code: string;
  zone_id: string | null;
  zone_name: string | null;
  shelf_id: string;
  shelf_name: string;
  row_label: string;
  row_index: number;
  slot_no: number;
  col_start: number;
  width_span: number;
  height_span: number;
  par_qty: number;
  on_hand_qty: number;
  counted_at: string | null;
  counted_by: string | null;
  version: number;
  co_located_parts: CoLocatedPart[];
}

export interface Part {
  part_id: string;
  part_code: string;
  part_name: string;
  category: string;
  description: string;
  department: Department;
  unit: string;
  cost: number | null;
  sale_price: number | null;
  reorder_point: number | null;
  width_in: number | null;
  height_in: number | null;
  depth_in: number | null;
  weight_lb: number | null;
  active: boolean;
  version: number;
  par_total: number;
  on_hand_total: number;
  locations: Location[];
}

export interface PartSearchResult {
  items: Part[];
  total: number;
}

// ---------- Events ----------

export interface EventRecord {
  event_id: string;
  at: string;
  by: string;
  action: string;
  entity: string;
  entity_id: string;
  before: unknown;
  after: unknown;
  reason: string | null;
  undone_by: string | null;
}

// ---------- Request bodies ----------

export interface PartCreate {
  part_code: string;
  part_name: string;
  category?: string;
  description?: string;
  department?: Department;
  unit?: string;
  cost?: number | null;
  sale_price?: number | null;
  reorder_point?: number | null;
  width_in?: number | null;
  height_in?: number | null;
  depth_in?: number | null;
  weight_lb?: number | null;
}

export type PartPatch = Partial<PartCreate> & { version: number };

export interface RegisterRow {
  part_code: string;
  part_name: string;
  category?: string;
  part_id?: string;
}

export interface RegisterResultRow {
  part_code: string;
  part_id: string | null;
  status: "reused" | "new" | "conflict";
  message?: string;
}

export interface StockAdjust {
  part_id: string;
  slot_id: string;
  delta?: number;
  set?: number;
  reason?: string;
  version?: number;
}

export interface LocationMove {
  part_id: string;
  from_slot_id?: string;
  to_slot_id: string;
  mode: MoveMode;
  par_qty?: number;
  on_hand_qty?: number;
}

/** ADDITION (C): PATCH /api/locations — edit the par level of one part in one slot. */
export interface LocationPatch {
  part_id: string;
  slot_id: string;
  par_qty: number;
  version: number;
}

export interface ShelfCreate {
  name: string;
  zone_id: string | null;
  kind: ShelfKind;
  x_in: number;
  y_in: number;
  rotation_deg: number;
  width_in: number;
  depth_in: number;
  height_in: number;
  cols: number;
  rows: Row[];
  wall_ref?: string | null;
  notes?: string;
}

export type ShelfPatch = Partial<ShelfCreate> & { version: number };

export interface SlotCreate {
  shelf_id: string;
  row_index: number;
  col_start: number;
  width_span: number;
  height_span: number;
  slot_no?: number;
  bin_type?: BinType;
  bin_width_in?: number | null;
  bin_height_in?: number | null;
  bin_depth_in?: number | null;
  bin_color?: string | null;
}

export interface SlotPatch {
  version: number;
  slot_no?: number;
  bin_type?: BinType;
  bin_width_in?: number | null;
  bin_height_in?: number | null;
  bin_depth_in?: number | null;
  bin_color?: string | null;
}

export interface SlotResize {
  width_span: number;
  height_span: number;
  col_start?: number;
  row_index?: number;
  anchor?: "bottom-left" | "bottom-right" | "top-left" | "top-right";
  version: number;
}

export type ZoneCreate = Omit<Zone, "zone_id" | "version">;
export type ZonePatch = Partial<ZoneCreate> & { version: number };
export type OpeningCreate = Omit<Opening, "opening_id" | "version">;
export type OpeningPatch = Partial<OpeningCreate> & { version: number };

// ---------- Write responses ----------
// ADDITION (C): every write response carries the event_id it recorded, so clients can offer
// Undo via POST /api/events/:event_id/undo.
export interface WriteMeta {
  event_id: string | null;
}
export type ShelfWrite = Shelf & WriteMeta;
export type SlotWrite = Slot & WriteMeta & { shelf_id: string };
export type PartWrite = Part & WriteMeta;
export type ZoneWrite = Zone & WriteMeta;
export type OpeningWrite = Opening & WriteMeta;
export interface LocationWrite extends WriteMeta {
  part: Part;
  affected_shelf_ids: string[]; // ADDITION (C): which shelves to refresh locally
}
export interface DeleteWrite extends WriteMeta {
  ok: true;
  affected_shelf_ids?: string[];
}
export interface UndoWrite extends WriteMeta {
  ok: true;
  undone_event_id: string;
  affected_shelf_ids: string[];
}

// ---------- Errors (§8) ----------

export type ErrorCode =
  | "validation"
  | "unauthorized"
  | "forbidden"
  | "not_found"
  | "slot_occupied"
  | "version_conflict"
  | "slot_out_of_bounds"
  | "slot_not_empty"
  | "shelf_not_empty"
  | "undo_stale"
  | "network"
  | "server";

export interface ErrorBody {
  error: ErrorCode;
  message: string;
  fields?: Record<string, string>;
  conflicts?: SlotConflict[];
  current?: unknown;
  slots?: { slot_id: string; location_code: string; reason: string }[]; // ADDITION (C) for slot_out_of_bounds
  [k: string]: unknown;
}

export interface SlotConflict {
  slot_id: string;
  location_code: string;
  parts: { part_id: string; part_name: string; on_hand_qty: number }[];
}
