// MODE: "mock" runs the in-browser mock API (src/shared/mock). "live" calls API_BASE.
// Flip DEFAULT_MODE to "live" once workstream A's Pages Functions are deployed.
// `?mode=live` / `?mode=mock` in the URL overrides it for testing.

export type Mode = "mock" | "live";

const DEFAULT_MODE: Mode = "mock";
export const API_BASE = "/api";

function readMode(): Mode {
  try {
    if (typeof window !== "undefined") {
      const m = new URLSearchParams(window.location.search).get("mode");
      if (m === "live" || m === "mock") return m;
    }
  } catch {
    /* ignore */
  }
  return DEFAULT_MODE;
}

export const MODE: Mode = readMode();
