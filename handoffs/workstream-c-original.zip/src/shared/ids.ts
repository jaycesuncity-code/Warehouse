// ID regexes and helpers. Validation only: the server mints every ID (contract §3).

export const ID_ALPHABET = "23456789abcdefghjkmnpqrstuvwxyz";
const BODY = "[2-9a-hj-km-np-z]{8}";

export type IdPrefix = "prt" | "zon" | "opn" | "shf" | "slt" | "evt";

export const ID_REGEX: Record<IdPrefix, RegExp> = {
  prt: new RegExp(`^prt-${BODY}$`),
  zon: new RegExp(`^zon-${BODY}$`),
  opn: new RegExp(`^opn-${BODY}$`),
  shf: new RegExp(`^shf-${BODY}$`),
  slt: new RegExp(`^slt-${BODY}$`),
  evt: new RegExp(`^evt-${BODY}$`),
};

/** Only labels matching this are accepted from a scan. */
export const PART_ID_REGEX = ID_REGEX.prt;

export function isPartId(s: string): boolean {
  return PART_ID_REGEX.test(s.trim());
}

export function isId(prefix: IdPrefix, s: string): boolean {
  return ID_REGEX[prefix].test(s);
}

/** Client-created records carry a temporary id until the server answers. */
export function isTempId(s: string): boolean {
  return s.startsWith("tmp-");
}

let tmpCounter = 0;
export function tempId(): string {
  tmpCounter += 1;
  return `tmp-${Date.now().toString(36)}${tmpCounter}`;
}
