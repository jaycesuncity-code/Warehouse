// One API client, identical in "mock" and "live" mode (src/shared/config.ts).
// Methods mirror every endpoint in contract §7. Errors throw a typed ApiError.

import { API_BASE, MODE } from "./config";
import type {
  DeleteWrite,
  ErrorBody,
  ErrorCode,
  EventRecord,
  Layout,
  LocationMove,
  LocationPatch,
  LocationWrite,
  Me,
  Opening,
  OpeningCreate,
  OpeningPatch,
  OpeningWrite,
  Part,
  PartCreate,
  PartPatch,
  PartSearchResult,
  PartWrite,
  RegisterResultRow,
  RegisterRow,
  Shelf,
  ShelfCreate,
  ShelfPatch,
  ShelfWrite,
  SlotCreate,
  SlotPatch,
  SlotResize,
  SlotWrite,
  StockAdjust,
  UndoWrite,
  Zone,
  ZoneCreate,
  ZonePatch,
  ZoneWrite,
} from "./contract";

export class ApiError extends Error {
  readonly status: number;
  readonly code: ErrorCode;
  readonly body: ErrorBody;
  constructor(status: number, body: ErrorBody) {
    super(body?.message || `Request failed (${status})`);
    this.status = status;
    this.code = body?.error ?? "server";
    this.body = body;
  }
  get isNetwork() {
    return this.code === "network";
  }
}

export function isApiError(e: unknown, code?: ErrorCode): e is ApiError {
  return e instanceof ApiError && (!code || e.code === code);
}

interface Req {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  query?: Record<string, string | number | boolean | undefined | null>;
  body?: unknown;
  headers?: Record<string, string>;
}

interface Raw {
  status: number;
  body: any;
  headers: Record<string, string>;
}

function toParams(q?: Req["query"]): URLSearchParams {
  const p = new URLSearchParams();
  if (q) for (const [k, v] of Object.entries(q)) if (v !== undefined && v !== null && v !== "") p.set(k, String(v));
  return p;
}

async function mockTransport(r: Req): Promise<Raw> {
  const mock = await import("./mock");
  try {
    return await mock.handle({ method: r.method, path: r.path, query: toParams(r.query), body: r.body, headers: r.headers });
  } catch (e) {
    throw new ApiError(0, { error: "network", message: "Can't reach the server. Check the connection." });
  }
}

async function liveTransport(r: Req): Promise<Raw> {
  const qs = toParams(r.query).toString();
  let res: Response;
  try {
    res = await fetch(`${API_BASE}${r.path}${qs ? `?${qs}` : ""}`, {
      method: r.method,
      headers: { accept: "application/json", ...(r.body !== undefined ? { "content-type": "application/json" } : {}), ...(r.headers ?? {}) },
      body: r.body !== undefined ? JSON.stringify(r.body) : undefined,
      credentials: "same-origin",
    });
  } catch {
    throw new ApiError(0, { error: "network", message: "Can't reach the server. Check the connection." });
  }
  const headers: Record<string, string> = {};
  res.headers.forEach((v, k) => (headers[k] = v));
  if (res.status === 304) return { status: 304, body: null, headers };
  const ct = res.headers.get("content-type") ?? "";
  const body = ct.includes("json") ? await res.json().catch(() => null) : await res.text();
  return { status: res.status, body, headers };
}

async function request<T>(r: Req): Promise<{ data: T; headers: Record<string, string>; status: number }> {
  const raw = MODE === "mock" ? await mockTransport(r) : await liveTransport(r);
  if (raw.status >= 400 || raw.status === 0) {
    const body: ErrorBody =
      raw.body && typeof raw.body === "object" && "error" in raw.body
        ? raw.body
        : { error: raw.status === 401 ? "unauthorized" : raw.status === 403 ? "forbidden" : raw.status === 404 ? "not_found" : "server", message: `Request failed (${raw.status})` };
    throw new ApiError(raw.status, body);
  }
  return { data: raw.body as T, headers: raw.headers, status: raw.status };
}

const get = async <T>(path: string, query?: Req["query"]) => (await request<T>({ method: "GET", path, query })).data;
const post = async <T>(path: string, body?: unknown) => (await request<T>({ method: "POST", path, body: body ?? {} })).data;
const patch = async <T>(path: string, body: unknown) => (await request<T>({ method: "PATCH", path, body })).data;
const del = async <T>(path: string, body?: unknown, query?: Req["query"]) => (await request<T>({ method: "DELETE", path, body, query })).data;
const enc = encodeURIComponent;

export type LayoutResult = { notModified: true; etag: string } | { notModified: false; etag: string | null; layout: Layout };

export const api = {
  mode: MODE,

  me: () => get<Me>("/me"),

  /** ETag-aware: pass the last etag to get `notModified: true` when nothing changed. */
  async getLayout(etag?: string | null): Promise<LayoutResult> {
    const r = await request<Layout>({ method: "GET", path: "/layout", headers: etag ? { "if-none-match": etag } : undefined });
    const tag = r.headers["etag"] ?? null;
    if (r.status === 304) return { notModified: true, etag: tag ?? etag ?? "" };
    return { notModified: false, etag: tag, layout: r.data };
  },

  // parts
  getPart: (id: string) => get<Part>(`/parts/${enc(id)}`),
  searchParts: (q: { q?: string; category?: string; limit?: number; offset?: number; unassigned?: boolean }) =>
    get<PartSearchResult>("/parts", { ...q, unassigned: q.unassigned ? "true" : undefined }),
  createPart: (body: PartCreate) => post<PartWrite>("/parts", body),
  patchPart: (id: string, body: PartPatch) => patch<PartWrite>(`/parts/${enc(id)}`, body),
  registerParts: (rows: RegisterRow[]) => post<{ rows: RegisterResultRow[]; event_id: string | null }>("/parts/register", { rows }),

  // stock + locations
  adjustStock: (body: StockAdjust) => post<LocationWrite>("/stock/adjust", body),
  moveLocation: (body: LocationMove) => post<LocationWrite>("/locations/move", body),
  deleteLocation: (body: { part_id: string; slot_id: string }) => del<LocationWrite & DeleteWrite>("/locations", body),
  /** ADDITION (C): edit par for one part in one slot (requires the location's version). */
  patchLocation: (body: LocationPatch) => patch<LocationWrite>("/locations", body),

  // shelves
  listShelves: () => get<{ zones: { zone_id: string | null; zone_name: string; shelves: (Omit<Shelf, "slots"> & { slot_count: number })[] }[] }>("/shelves"),
  getShelf: (id: string) => get<Shelf>(`/shelves/${enc(id)}`),
  createShelf: (body: ShelfCreate) => post<ShelfWrite>("/shelves", body),
  patchShelf: (id: string, body: ShelfPatch) => patch<ShelfWrite>(`/shelves/${enc(id)}`, body),
  deleteShelf: (id: string, opts?: { force?: boolean }) => del<DeleteWrite>(`/shelves/${enc(id)}`, undefined, { force: opts?.force ? "true" : undefined }),
  duplicateShelf: (id: string) => post<ShelfWrite>(`/shelves/${enc(id)}/duplicate`),

  // slots
  createSlot: (body: SlotCreate) => post<SlotWrite>("/slots", body),
  patchSlot: (id: string, body: SlotPatch) => patch<SlotWrite>(`/slots/${enc(id)}`, body),
  resizeSlot: (id: string, body: SlotResize) => post<SlotWrite>(`/slots/${enc(id)}/resize`, body),
  deleteSlot: (id: string) => del<DeleteWrite>(`/slots/${enc(id)}`),

  // building
  listZones: () => get<{ items: Zone[] }>("/zones"),
  createZone: (body: ZoneCreate) => post<ZoneWrite>("/zones", body),
  patchZone: (id: string, body: ZonePatch) => patch<ZoneWrite>(`/zones/${enc(id)}`, body),
  listOpenings: () => get<{ items: Opening[] }>("/openings"),
  createOpening: (body: OpeningCreate) => post<OpeningWrite>("/openings", body),
  patchOpening: (id: string, body: OpeningPatch) => patch<OpeningWrite>(`/openings/${enc(id)}`, body),

  // history
  events: (q: { entity?: string; entity_id?: string; limit?: number }) => get<{ items: EventRecord[] }>("/events", q),
  undoEvent: (eventId: string) => post<UndoWrite>(`/events/${enc(eventId)}/undo`),

  exportCsv: () => get<string>("/export.csv"),
};

export type Api = typeof api;
