// In-browser mock of the whole API (contract §7). api.ts calls `handle()` in mock mode, so the
// client code is identical in mock and live mode. Extend by adding a function to endpoints.ts
// and a line to ROUTES.

import type { Role } from "../contract";
import { evenRows, round16 } from "../units";
import { getDB, mintId, resetDB, setDB, setPersistEnabled, setRole, getRole, sim, type DB } from "./db";
import * as E from "./endpoints";
import { MockHttpError, type Ctx, type Res } from "./endpoints";

type Handler = (ctx: Ctx) => Res;

const ROUTES: [string, string, Handler][] = [
  ["GET", "/me", E.getMe],
  ["GET", "/layout", E.getLayout],
  ["GET", "/parts", E.searchParts],
  ["POST", "/parts", E.createPart],
  ["POST", "/parts/register", E.registerParts],
  ["GET", "/parts/:part_id", E.getPart],
  ["PATCH", "/parts/:part_id", E.patchPart],
  ["POST", "/stock/adjust", E.adjustStock],
  ["POST", "/locations/move", E.moveLocation],
  ["DELETE", "/locations", E.deleteLocation],
  ["PATCH", "/locations", E.patchLocation], // ADDITION (C)
  ["GET", "/shelves", E.listShelves],
  ["POST", "/shelves", E.createShelf],
  ["GET", "/shelves/:shelf_id", E.getShelf],
  ["PATCH", "/shelves/:shelf_id", E.patchShelf],
  ["DELETE", "/shelves/:shelf_id", E.deleteShelf],
  ["POST", "/shelves/:shelf_id/duplicate", E.duplicateShelf],
  ["POST", "/slots", E.createSlot],
  ["PATCH", "/slots/:slot_id", E.patchSlot],
  ["POST", "/slots/:slot_id/resize", E.resizeSlot],
  ["DELETE", "/slots/:slot_id", E.deleteSlot],
  ["GET", "/zones", E.listZones],
  ["POST", "/zones", E.createZone],
  ["PATCH", "/zones/:zone_id", E.patchZone],
  ["GET", "/openings", E.listOpenings],
  ["POST", "/openings", E.createOpening],
  ["PATCH", "/openings/:opening_id", E.patchOpening],
  ["GET", "/events", E.listEvents],
  ["POST", "/events/:event_id/undo", E.undoEvent],
  ["GET", "/export.csv", E.exportCsv],
];

function match(pattern: string, path: string): Record<string, string> | null {
  const a = pattern.split("/");
  const b = path.split("/");
  if (a.length !== b.length) return null;
  const params: Record<string, string> = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(":")) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

export interface MockRequest {
  method: string;
  path: string; // e.g. "/shelves/shf-xxxx" (no /api prefix)
  query?: URLSearchParams;
  body?: unknown;
  headers?: Record<string, string>;
}

export interface MockResponse {
  status: number;
  body: unknown;
  headers: Record<string, string>;
}

/** Synchronous core (used by tests). */
export function handleSync(req: MockRequest): MockResponse {
  const method = req.method.toUpperCase();
  for (const [m, pattern, fn] of ROUTES) {
    if (m !== method) continue;
    const params = match(pattern, req.path);
    if (!params) continue;
    try {
      const res = fn({ params, query: req.query ?? new URLSearchParams(), body: structuredClone(req.body ?? null), headers: req.headers ?? {} });
      return { status: res.status ?? 200, body: res.body, headers: res.headers ?? {} };
    } catch (e) {
      if (e instanceof MockHttpError) return { status: e.status, body: e.body, headers: {} };
      console.error("[mock] internal error", e);
      return { status: 500, body: { error: "server", message: e instanceof Error ? e.message : String(e) }, headers: {} };
    }
  }
  return { status: 404, body: { error: "not_found", message: `No mock route for ${method} ${req.path}` }, headers: {} };
}

/** Async entry used by api.ts: adds simulated latency and offline mode. */
export async function handle(req: MockRequest): Promise<MockResponse> {
  if (sim.latencyMs > 0) await new Promise((r) => setTimeout(r, sim.latencyMs));
  if (sim.offline) throw new TypeError("Failed to fetch (mock offline)");
  return handleSync(req);
}

// ---------------- demo controls ----------------

export function resetDemoData(): void {
  resetDB();
}

export function setMockRole(role: Role): void {
  setRole(role);
}

export function getMockRole(): Role {
  return getRole();
}

export function setMockOffline(offline: boolean): void {
  sim.offline = offline;
}

export function setMockLatency(ms: number): void {
  sim.latencyMs = ms;
}

/**
 * Performance dataset: adds generated shelves (on top of the demo data) laid out in aisles
 * inside the building, until there are `shelves` shelves and roughly `slots` slots in total.
 * Not persisted to localStorage.
 */
export function seedPerfData(shelves = 300, slots = 5000): { shelves: number; slots: number } {
  const d: DB = structuredClone(getDB());
  const zoneOf = (x: number, y: number) =>
    d.zones.find((z) => {
      const p = z.polygon_in;
      let inside = false;
      for (let i = 0, j = p.length - 1; i < p.length; j = i++) {
        const [xi, yi] = p[i];
        const [xj, yj] = p[j];
        if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
      }
      return inside;
    })?.zone_id ?? null;
  const need = Math.max(0, shelves - d.shelves.filter((s) => s.active).length);
  const slotsPerShelf = Math.max(1, Math.round((slots - d.slots.filter((s) => s.active).length) / Math.max(1, need)));
  // Aisles: 48" wide x 24" deep units in back-to-back pairs, 48" aisles.
  // Each spot is a ready front-left placement. A back-to-back pair occupies y0..y0+48:
  //   rot 180 (faces north): front-left (x+48, y0) spans X x..x+48, Y y0..y0+24
  //   rot 0   (faces south): front-left (x, y0+48) spans X x..x+48, Y y0+24..y0+48
  const spots: { x_in: number; y_in: number; r: number }[] = [];
  const regions = [
    { x0: 80, x1: 460, y0: 40, y1: 1160 }, // warehouse 126 (clear of west-wall demo shelves)
    { x0: 660, x1: 980, y0: 800, y1: 1180 }, // fabrication 124
    { x0: 20, x1: 1180, y0: 1230, y1: 1380 }, // fabrication 123 north part
    { x0: 20, x1: 460, y0: 1700, y1: 1930 }, // filters 120
    { x0: 340, x1: 840, y0: 1500, y1: 1670 }, // 121
    { x0: 1010, x1: 1190, y0: 790, y1: 1190 }, // loading dock
    { x0: 880, x1: 1190, y0: 1400, y1: 1670 }, // fabrication 123 east part
  ];
  for (const r of regions) {
    for (let y = r.y0; y + 96 < r.y1; y += 96) {
      for (let x = r.x0; x + 48 < r.x1; x += 52) {
        spots.push({ x_in: x + 48, y_in: y, r: 180 }, { x_in: x, y_in: y + 48, r: 0 });
      }
    }
  }
  let made = 0;
  const taken = new Set(d.shelves.map((s) => s.name));
  for (const s of spots) {
    if (made >= need) break;
    const rot = s.r;
    const { x_in, y_in } = s;
    const cx = rot === 0 ? x_in + 24 : x_in - 24;
    const cy = rot === 0 ? y_in - 12 : y_in + 12;
    const zone_id = zoneOf(cx, cy);
    if (!zone_id) continue;
    let name = `P${made + 1}`;
    while (taken.has(name)) name = `${name}x`;
    taken.add(name);
    const shelf_id = mintId("shf", d);
    const rows = evenRows(5, 84);
    d.shelves.push({
      shelf_id, name, zone_id, kind: "shelving", x_in: round16(x_in), y_in: round16(y_in), rotation_deg: rot,
      width_in: 48, depth_in: 24, height_in: 84, cols: 6, rows, wall_ref: null, notes: "Perf test", version: 1, active: true,
    });
    // fill slots row by row (2-col and 1-col mix) up to slotsPerShelf
    let count = 0;
    for (let r = 0; r < rows.length && count < slotsPerShelf; r++) {
      let c = 1;
      let no = 1;
      while (c <= 6 && count < slotsPerShelf) {
        const w = (r + c) % 3 === 0 && c < 6 ? 2 : 1;
        d.slots.push({
          slot_id: mintId("slt", d), shelf_id, slot_no: no++, row_index: r, col_start: c, width_span: w, height_span: 1,
          bin_type: "bin", bin_width_in: null, bin_height_in: null, bin_depth_in: null, bin_color: null, version: 1, active: true,
        });
        c += w;
        count++;
      }
    }
    made++;
  }
  d.seq += 1;
  setPersistEnabled(false);
  setDB(d);
  return { shelves: d.shelves.filter((s) => s.active).length, slots: d.slots.filter((s) => s.active).length };
}

// Handy in the browser console during demos: __mock.setOffline(true), __mock.seedPerfData()
if (typeof window !== "undefined") {
  (window as any).__mock = { resetDemoData, setMockRole, setOffline: setMockOffline, setLatency: setMockLatency, seedPerfData, getDB };
}
