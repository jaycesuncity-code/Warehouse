import { beforeEach, describe, expect, it } from "vitest";
import { handleSync, resetDemoData, setMockRole } from "./index";
import { getDB } from "./db";
import { DEMO_LOCATIONS, DEMO_OPENINGS, DEMO_PARTS, DEMO_SHELVES, DEMO_SLOTS, DEMO_ZONES } from "./demo-data";
import { ID_REGEX, isPartId } from "../ids";
import { slotsOverlap } from "./rules";
import type { Layout, LayoutShelf, Part, Shelf } from "../contract";

const call = (method: string, path: string, body?: unknown, query?: Record<string, string>) =>
  handleSync({ method, path, body, query: new URLSearchParams(query) });

function shelfByName(name: string): Shelf {
  const id = getDB().shelves.find((s) => s.name === name && s.active)!.shelf_id;
  return call("GET", `/shelves/${id}`).body as Shelf;
}

function assertConsistent() {
  const d = getDB();
  for (const shelf of d.shelves.filter((s) => s.active)) {
    const slots = d.slots.filter((s) => s.active && s.shelf_id === shelf.shelf_id);
    for (let i = 0; i < slots.length; i++)
      for (let j = i + 1; j < slots.length; j++) expect(slotsOverlap(slots[i], slots[j]), `${shelf.name} overlap`).toBe(false);
    for (const s of slots) {
      expect(s.col_start + s.width_span - 1).toBeLessThanOrEqual(shelf.cols);
      expect(s.row_index + s.height_span - 1).toBeLessThan(shelf.rows.length);
    }
  }
  for (const l of d.locations.filter((x) => x.active)) {
    expect(l.on_hand_qty).toBeGreaterThanOrEqual(0);
    expect(d.slots.find((s) => s.slot_id === l.slot_id)?.active).toBe(true);
  }
}

beforeEach(() => {
  resetDemoData();
  setMockRole("editor");
});

describe("demo data (contract §9)", () => {
  it("every ID matches its regex", () => {
    for (const z of DEMO_ZONES) expect(z.zone_id).toMatch(ID_REGEX.zon);
    for (const o of DEMO_OPENINGS) expect(o.opening_id).toMatch(ID_REGEX.opn);
    for (const s of DEMO_SHELVES) expect(s.shelf_id).toMatch(ID_REGEX.shf);
    for (const s of DEMO_SLOTS) expect(s.slot_id).toMatch(ID_REGEX.slt);
    for (const p of DEMO_PARTS) expect(isPartId(p.part_id)).toBe(true);
  });
  it("has the required edge cases", () => {
    const perPart = new Map<string, number>();
    const perSlot = new Map<string, number>();
    for (const l of DEMO_LOCATIONS) {
      perPart.set(l.part_id, (perPart.get(l.part_id) ?? 0) + 1);
      perSlot.set(l.slot_id, (perSlot.get(l.slot_id) ?? 0) + 1);
    }
    expect([...perPart.values()].some((n) => n >= 2)).toBe(true); // part in two slots
    expect([...perSlot.values()].some((n) => n >= 2)).toBe(true); // slot holding two parts
    expect(DEMO_PARTS.some((p) => !perPart.has(p.part_id))).toBe(true); // part with no location
    expect(DEMO_LOCATIONS.some((l) => l.on_hand_qty === 0)).toBe(true);
    expect(DEMO_LOCATIONS.some((l) => l.on_hand_qty > l.par_qty)).toBe(true);
    expect(DEMO_PARTS.some((p) => /^0/.test(p.part_code))).toBe(true);
    expect(DEMO_ZONES.every((z) => !z.verified) && DEMO_OPENINGS.every((o) => !o.verified)).toBe(true);
    assertConsistent();
  });
  it("matches the contract's B1-G-4 example (col 7, 2 wide)", () => {
    const b1 = shelfByName("B1");
    const s = b1.slots.find((x) => x.location_code === "B1-G-4")!;
    expect([s.col_start, s.width_span, s.height_span]).toEqual([7, 2, 1]);
    expect(s.parts[0].part_id).toBe("prt-k7m2qx9d");
  });
});

describe("layout + ETag", () => {
  it("returns 304 when nothing changed and a new version after a write", () => {
    const first = handleSync({ method: "GET", path: "/layout" });
    const etag = first.headers.etag;
    expect(handleSync({ method: "GET", path: "/layout", headers: { "if-none-match": etag } }).status).toBe(304);
    const a1 = shelfByName("A1");
    call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, notes: "x" });
    const again = handleSync({ method: "GET", path: "/layout", headers: { "if-none-match": etag } });
    expect(again.status).toBe(200);
    const layout = again.body as Layout;
    const ls = layout.shelves.find((s) => s.name === "B1") as LayoutShelf;
    const g4 = ls.slots.find((s) => s.location_code === "B1-G-4")!;
    expect(g4).toMatchObject({ part_count: 1, on_hand_total: 62, par_total: 100, low: true, part_ids: ["prt-k7m2qx9d"] });
  });
});

describe("roles", () => {
  it("viewer can't write", () => {
    setMockRole("viewer");
    const a1 = shelfByName("A1");
    expect(call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, x_in: 30 }).status).toBe(403);
  });
  it("editor can't edit zones; admin can", () => {
    const z = getDB().zones[0];
    expect(call("PATCH", `/zones/${z.zone_id}`, { version: z.version, verified: true }).status).toBe(403);
    setMockRole("admin");
    const r = call("PATCH", `/zones/${z.zone_id}`, { version: z.version, verified: true });
    expect(r.status).toBe(200);
    expect((r.body as any).verified).toBe(true);
  });
});

describe("shelves", () => {
  it("creates with a server-minted id", () => {
    const r = call("POST", "/shelves", {
      name: "Z9", zone_id: null, kind: "shelving", x_in: 200, y_in: 300, rotation_deg: 0, width_in: 48, depth_in: 24, height_in: 84, cols: 6,
      rows: [{ row_index: 0, row_label: "G", elevation_in: 4, clear_height_in: 20 }],
    });
    expect(r.status).toBe(201);
    expect((r.body as Shelf).shelf_id).toMatch(ID_REGEX.shf);
    expect((r.body as any).event_id).toMatch(ID_REGEX.evt);
  });
  it("refuses nothing west of X = 0", () => {
    const r = call("POST", "/shelves", {
      name: "W", zone_id: null, kind: "shelving", x_in: -10, y_in: 300, rotation_deg: 0, width_in: 48, depth_in: 24, height_in: 84, cols: 6,
      rows: [{ row_index: 0, row_label: "G", elevation_in: 4, clear_height_in: 20 }],
    });
    expect(r.status).toBe(400);
  });
  it("version conflict returns the current row and doesn't write", () => {
    const a1 = shelfByName("A1");
    expect(call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, x_in: 30 }).status).toBe(200);
    const stale = call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, x_in: 40 });
    expect(stale.status).toBe(409);
    expect((stale.body as any).error).toBe("version_conflict");
    expect((stale.body as any).current.x_in).toBe(30);
    expect(shelfByName("A1").x_in).toBe(30);
  });
  it("slot_out_of_bounds when cols shrink under a slot", () => {
    const a1 = shelfByName("A1");
    const r = call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, cols: 10 });
    expect(r.status).toBe(409);
    expect((r.body as any).error).toBe("slot_out_of_bounds");
    expect((r.body as any).slots.length).toBeGreaterThan(0);
    expect(shelfByName("A1").cols).toBe(12);
  });
  it("shelf_not_empty unless admin forces", () => {
    const a1 = shelfByName("A1");
    const r = call("DELETE", `/shelves/${a1.shelf_id}`);
    expect(r.status).toBe(409);
    expect((r.body as any).error).toBe("shelf_not_empty");
    setMockRole("admin");
    expect(call("DELETE", `/shelves/${a1.shelf_id}`, undefined, { force: "true" }).status).toBe(200);
    assertConsistent();
  });
  it("duplicate copies rows and empty slots offset by one width", () => {
    const a1 = shelfByName("A1");
    const r = call("POST", `/shelves/${a1.shelf_id}/duplicate`);
    const copy = r.body as Shelf;
    expect(copy.name).toBe("A3"); // A2 exists
    expect(copy.x_in).toBe(24);
    expect(copy.y_in).toBe(864); // rotation 270: width runs north
    expect(copy.slots.length).toBe(a1.slots.length);
    expect(copy.slots.every((s) => s.parts.length === 0)).toBe(true);
    assertConsistent();
  });
});

describe("slots", () => {
  it("409 slot_occupied on overlap, with conflicts", () => {
    const a1 = shelfByName("A1");
    const r = call("POST", "/slots", { shelf_id: a1.shelf_id, row_index: 0, col_start: 2, width_span: 2, height_span: 1 });
    expect(r.status).toBe(409);
    expect((r.body as any).conflicts.map((c: any) => c.location_code)).toEqual(["A1-G-1", "A1-G-2"]);
  });
  it("resize into an overlap is refused; into free space works", () => {
    const a2 = shelfByName("A2");
    const s = a2.slots.find((x) => x.location_code === "A2-3-1")!; // full-width top row
    const shrink = call("POST", `/slots/${s.slot_id}/resize`, { width_span: 6, height_span: 1, version: s.version });
    expect(shrink.status).toBe(200);
    const g1 = a2.slots.find((x) => x.location_code === "A2-G-1")!;
    const grow = call("POST", `/slots/${g1.slot_id}/resize`, { width_span: 4, height_span: 1, version: g1.version });
    expect(grow.status).toBe(409);
    expect((grow.body as any).error).toBe("slot_occupied");
    assertConsistent();
  });
  it("resize anchor bottom-right keeps the right edge", () => {
    const a2 = shelfByName("A2");
    const s = a2.slots.find((x) => x.location_code === "A2-3-1")!;
    const r = call("POST", `/slots/${s.slot_id}/resize`, { width_span: 4, height_span: 1, anchor: "bottom-right", version: s.version });
    expect((r.body as any).col_start).toBe(9);
  });
  it("can't delete a slot holding parts", () => {
    const a1 = shelfByName("A1");
    const s = a1.slots.find((x) => x.parts.length)!;
    expect((call("DELETE", `/slots/${s.slot_id}`).body as any).error).toBe("slot_not_empty");
  });
});

describe("stock and locations", () => {
  const ELBOW = "prt-k7m2qx9d";
  it("never goes below 0", () => {
    const p = call("GET", `/parts/${ELBOW}`).body as Part;
    const loc = p.locations[0];
    expect(call("POST", "/stock/adjust", { part_id: ELBOW, slot_id: loc.slot_id, delta: -(loc.on_hand_qty + 1) }).status).toBe(400);
    expect(call("POST", "/stock/adjust", { part_id: ELBOW, slot_id: loc.slot_id, delta: -1 }).status).toBe(200);
  });
  it("set needs the location version", () => {
    const loc = (call("GET", `/parts/${ELBOW}`).body as Part).locations[0];
    expect(call("POST", "/stock/adjust", { part_id: ELBOW, slot_id: loc.slot_id, set: 5 }).status).toBe(400);
    expect(call("POST", "/stock/adjust", { part_id: ELBOW, slot_id: loc.slot_id, set: 5, version: loc.version + 3 }).status).toBe(409);
    expect(call("POST", "/stock/adjust", { part_id: ELBOW, slot_id: loc.slot_id, set: 5, version: loc.version }).status).toBe(200);
  });
  it("add into an occupied slot -> 409; share works; swap exchanges", () => {
    const a1 = shelfByName("A1");
    const occupied = a1.slots.find((s) => s.location_code === "A1-G-1")!; // push coupling
    const free = a1.slots.find((s) => s.parts.length === 0)!;
    const unassigned = "prt-c7tn2vrd";
    const r = call("POST", "/locations/move", { part_id: unassigned, to_slot_id: occupied.slot_id, mode: "add", par_qty: 10, on_hand_qty: 4 });
    expect(r.status).toBe(409);
    expect((r.body as any).error).toBe("slot_occupied");
    expect((r.body as any).conflicts[0].parts[0].part_id).toBe("prt-v6np3jtw");
    const shared = call("POST", "/locations/move", { part_id: unassigned, to_slot_id: occupied.slot_id, mode: "share", par_qty: 10, on_hand_qty: 4 });
    expect(shared.status).toBe(200);
    expect(shelfByName("A1").slots.find((s) => s.slot_id === occupied.slot_id)!.parts.length).toBe(2);
    // move the filter to a free slot, then swap it with the coupling
    const mv = call("POST", "/locations/move", { part_id: unassigned, from_slot_id: occupied.slot_id, to_slot_id: free.slot_id, mode: "move" });
    expect(mv.status).toBe(200);
    const sw = call("POST", "/locations/move", { part_id: unassigned, from_slot_id: free.slot_id, to_slot_id: occupied.slot_id, mode: "swap" });
    expect(sw.status).toBe(200);
    const after = shelfByName("A1");
    expect(after.slots.find((s) => s.slot_id === occupied.slot_id)!.parts.map((p) => p.part_id)).toEqual([unassigned]);
    expect(after.slots.find((s) => s.slot_id === free.slot_id)!.parts.map((p) => p.part_id)).toEqual(["prt-v6np3jtw"]);
    // quantities carried
    const coupling = (call("GET", "/parts/prt-v6np3jtw").body as Part).locations[0];
    expect([coupling.par_qty, coupling.on_hand_qty]).toEqual([20, 14]);
    assertConsistent();
  });
});

describe("events and undo", () => {
  it("undoes a shelf move, and refuses a stale undo", () => {
    const a1 = shelfByName("A1");
    const moved = call("PATCH", `/shelves/${a1.shelf_id}`, { version: a1.version, x_in: 60 }).body as any;
    const undo = call("POST", `/events/${moved.event_id}/undo`);
    expect(undo.status).toBe(200);
    expect(shelfByName("A1").x_in).toBe(24);
    expect((call("POST", `/events/${moved.event_id}/undo`).body as any).error).toBe("undo_stale");
    // stale: change after the event
    const b = shelfByName("A1");
    const m2 = call("PATCH", `/shelves/${b.shelf_id}`, { version: b.version, x_in: 70 }).body as any;
    const c = shelfByName("A1");
    call("PATCH", `/shelves/${c.shelf_id}`, { version: c.version, x_in: 80 });
    expect((call("POST", `/events/${m2.event_id}/undo`).body as any).error).toBe("undo_stale");
  });
  it("undoes a create by soft-deleting", () => {
    const a1 = shelfByName("A1");
    const created = call("POST", "/slots", { shelf_id: a1.shelf_id, row_index: 1, col_start: 5, width_span: 1, height_span: 1 });
    expect(created.status).toBe(409); // A1-G-3 spans into row 1 cols 5-7
    const a2 = shelfByName("A2");
    const ok = call("POST", `/slots/${a2.slots.find((s) => s.location_code === "A2-3-1")!.slot_id}/resize`, {
      width_span: 6, height_span: 1, version: a2.slots.find((s) => s.location_code === "A2-3-1")!.version,
    });
    expect(ok.status).toBe(200);
    const made = call("POST", "/slots", { shelf_id: a2.shelf_id, row_index: 3, col_start: 7, width_span: 6, height_span: 1 }).body as any;
    expect(shelfByName("A2").slots.some((s) => s.slot_id === made.slot_id)).toBe(true);
    call("POST", `/events/${made.event_id}/undo`);
    expect(shelfByName("A2").slots.some((s) => s.slot_id === made.slot_id)).toBe(false);
  });
});
