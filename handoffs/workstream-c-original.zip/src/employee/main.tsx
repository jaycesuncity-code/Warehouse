// PLACEHOLDER (workstream B owns this page).
import { createRoot } from "react-dom/client";
import "../shared/ui/base.css";
import { Header } from "../shared/ui";

createRoot(document.getElementById("root")!).render(
  <div className="min-h-full">
    <Header title="Employee version" subtitle="Coming later" back="../" />
    <main className="p-6 text-gray-700">The Employee version comes in a later step.</main>
  </div>,
);
