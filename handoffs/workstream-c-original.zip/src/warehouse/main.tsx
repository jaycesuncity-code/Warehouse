// PLACEHOLDER: workstream B's Warehouse scan app replaces this page. It only shows how the scan app
// deep-links into the map (/map/?shelf=&slot=&part=).
import { createRoot } from "react-dom/client";
import "../shared/ui/base.css";
import { DemoBadge, Header } from "../shared/ui";

function Placeholder() {
  const part = new URLSearchParams(window.location.search).get("part") ?? "prt-k7m2qx9d";
  return (
    <div className="min-h-full">
      <Header title="Warehouse version" subtitle="Scan app (workstream B)" back="../">
        <DemoBadge />
      </Header>
      <main className="mx-auto max-w-xl space-y-3 p-6">
        <p>The scan app from workstream B goes here. Its "Open in 3D map" button links like this:</p>
        <a className="btn-primary" href={`../map/?part=${encodeURIComponent(part)}`} data-testid="open-in-map">
          Open {part} in the map
        </a>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<Placeholder />);
