// PLACEHOLDER (workstream B owns this page). Kept minimal so the multi-page build runs.
import { createRoot } from "react-dom/client";
import "../shared/ui/base.css";
import { DemoBadge, Header } from "../shared/ui";

function Home() {
  return (
    <div className="min-h-full">
      <Header title="Sun City Parts" subtitle="Plumbing & Heating · Las Cruces">
        <DemoBadge />
      </Header>
      <main className="mx-auto grid max-w-3xl gap-4 p-6 sm:grid-cols-2">
        <a href="warehouse/" className="flex min-h-[160px] flex-col justify-center rounded-2xl bg-maroon p-6 text-white shadow-lg hover:bg-maroon-light" data-testid="home-warehouse">
          <span className="text-2xl font-extrabold">Warehouse version</span>
          <span className="mt-1 text-gold-light">Scan labels, counts, moves</span>
        </a>
        <a href="employee/" className="flex min-h-[160px] flex-col justify-center rounded-2xl border-4 border-maroon bg-white p-6 text-maroon shadow-lg hover:bg-maroon-tint" data-testid="home-employee">
          <span className="text-2xl font-extrabold">Employee version</span>
          <span className="mt-1 text-gray-600">Coming later</span>
        </a>
        <a href="map/" className="rounded-2xl border-b-4 border-gold bg-white p-5 shadow sm:col-span-2" data-testid="home-map">
          <span className="text-lg font-bold text-maroon">Warehouse map</span>
          <span className="block text-sm text-gray-600">Find any part on the 3D shop map, and lay out shelves, rows and bins.</span>
        </a>
      </main>
    </div>
  );
}

createRoot(document.getElementById("root")!).render(<Home />);
