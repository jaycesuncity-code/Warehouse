# Sun City Plumbing & Heating — warehouse parts app

One Cloudflare Pages project, one Vite multi-page build:

| Page | Path | Owner |
|---|---|---|
| Home (two big buttons) | `/` | B (placeholder here) |
| Warehouse scan app | `/warehouse/` | B (placeholder here) |
| Employee version | `/employee/` | B (placeholder here) |
| **3D warehouse map + layout editor** | **`/map/`** | **C (this README section)** |
| API (Pages Functions + D1) | `/api/*` | A |

## Run it

```bash
npm install
npm run dev          # http://localhost:5173/map/
npm run typecheck && npm test && npm run build
npm run test:e2e     # Playwright, against the production build (run `npm run build` first)
```

Everything runs on the in-browser **mock API** (`src/shared/mock/`) until `DEFAULT_MODE` in
`src/shared/config.ts` is flipped to `"live"`. `?mode=live` / `?mode=mock` in the URL overrides it.
In mock mode the header shows **DEMO DATA**, a role switcher (viewer / editor / admin) and **Reset demo data**.
Demo edits are kept in the browser's localStorage.

Mock-only URL options for the map: `?perf=1` (300 shelves / ~5,000 slots), `?latency=600` (slow API).
In the browser console: `__mock.setOffline(true)` to test the offline banner.

---

## The map (`/map/`)

A navigable 3D and top-down model of the shop's warehouse side, plus the layout editor used while
sorting the warehouse. Everything saves through `src/shared/api.ts` (mock now, D1 later).

### Finding a part (search first)

The page opens in the **top-down plan** with the search box focused.

- Type a part name, code or category. Every shelf holding a match gets a **pulsing maroon dot**, and the
  result list groups matches by zone and shelf.
- As results narrow, the view zooms: matches on several shelves → fits them all; all on **one shelf** → zooms
  to it and opens its front view with the matching slots glowing; **one slot** → zooms to the slot and opens the
  part card; nothing → **"No results"**. Clearing the search zooms back out.
- Scan a label with the 📷 button, or with a handheld (keyboard-wedge) scanner anywhere on the page: a `prt-` ID
  jumps straight to the part's slots.
- With "reduce motion" turned on in the OS, the camera cuts instead of flying and the dots don't pulse.

### Controls and shortcuts

| | |
|---|---|
| **Plan / 3D / Walk** | top-down plan · 3D orbit · first-person walk |
| Plan | drag = pan, wheel / pinch = zoom (north is always up; 1 ft and 5 ft grid; axis in feet) |
| 3D | left-drag = orbit, right-drag = pan, wheel = zoom, **double-click** the floor = orbit around that point |
| Walk | click the view to look around, **W A S D** / arrows to walk, **Shift** to run, **Esc** to exit. Phones: joystick + drag to look |
| `/` | focus the search box |
| `F` | fit the whole building |
| `Esc` | cancel the current tool, then clear the selection |
| `R` / `Shift+R` | rotate the selected shelf 90° / 15° (Edit) |
| `Ctrl+D` | duplicate the selected shelf (Edit) |
| `Del` | delete the selected shelf, after a confirm (Edit) |
| `Ctrl+Z` / `Ctrl+Y` | undo / redo (this session) |

Left panel: **Layout** (zones → shelves → rows → slots; click to select and fly there) and **Parts** (search,
**Unassigned parts**, drag a part onto a slot). Right panel: the part card and the inspector. Phones get the same
panels as bottom sheets (Results, Details, Layout, Parts).

**Color** by fill state (empty / has stock / below par / out), department, zone or unverified. **⋯** has wall
cutaway, x-ray walls, isolate one zone, hide empty slots, the survey-sheet toggle, warning thresholds, and
layout snapshot export / import.

### Editing (Edit mode: `editor` or `admin`)

- **+ Add shelf**: pick a preset (4' shelving, 8' shelving, pallet rack bay, cabinet, bench, floor area, or
  last-used size), then click the floor. Shift-click to place several.
- **Move**: drag a shelf. It snaps to the grid (off / 1 in / 6 in / 1 ft) and, with **edges** on, to walls and to
  other shelves' corners, edges and backs, so units line up end to end and back to back. One save on release.
- **Exact entry**: type X, Y and rotation in the inspector (feet-inches, e.g. `40'-3"`, `40-3`, `483"`).
- **Row tool**: adds N identical units end to end, continuing to the right of the selected one.
- **Live warnings** (never block saving): overlap, outside every zone, blocking a door or the clearance in front of
  an overhead door, aisle narrower than 3' to the facing unit (the aisle width is drawn), and the "No high-pile
  storage allowed" reminder in WAREHOUSE 126 for units over 12'. Thresholds are in **⋯**. The high-pile one is a
  reminder, not a code check.
- **Front view** (select a shelf → **Front view**): drawn to scale like the paper shelf sheets: height up the left,
  distance from the left edge along the bottom, standing in the aisle facing the shelf.
  - drag a deck's ⇕ grip to move a row; **+ Row** / **− Top row**; **Cols** sets the columns (cell width shown)
  - drag across empty cells to **draw a slot**, or **Fill row** with N equal slots
  - click a slot, then drag its gold edges to **resize** (overlaps show red and are refused)
  - **Renumber L→R** (asks first, because location codes may be printed)
  - drop parts on slots
- **Slot inspector**: parts with on hand / par / status, ±1, count, par, **Move…**, **Remove**, **Add part**;
  bin type, color and real W × H × D (warns when the bin is bigger than its slot); a fit check
  ("about N fit") when the part has dimensions.
- **Occupied slot**: the same choices as the scan app: swap, share the slot, choose a different spot, or cancel.
- **Changed by someone else**: **Reload** for everyone; **Overwrite** for admins only.
- **Offline**: a banner appears, failed edits stay listed with Retry / Discard and are resent automatically when the
  API is back. Nothing is dropped silently.

### How coordinates work

- **Map coordinates** (what the database, the API and this page use): inches, origin at the **north-west corner of
  WAREHOUSE 126**, **X east**, **Y south**, height up from the finished floor. These are the coordinates printed on
  the A-1 room survey map. In 3D, world x = X, z = Y, y = height, 1 unit = 1 inch.
- **Survey-sheet coordinates**: some printed grid sheets use the outside **south-west corner of STORAGE - FILTERS
  120** as the origin, with Y running **north**. Then `X_map = X_sheet` and `Y_map = 162'-3" (1947 in) − Y_sheet`.
  Tick **Enter from survey sheet** (inspector or **⋯**) and type the numbers from the sheet as they are; the map
  converts them. The cursor readout and the plan's Y axis show sheet values too while it's on.
  Printing grid paper with origin "Top-left (north-west)" gives map coordinates directly.
- A shelf's position is its **front-left corner** (standing in the aisle facing it) plus a rotation:
  0° faces south, 90° west, 180° north, 270° east.
- Nothing west of X = 0 (the office side) is modeled or editable; it's drawn as a flat gray strip.

### Entering a tape measurement ("Place from wall")

Select the shelf → **Place from wall (tape measurement)**. These are the columns of the paper measurement log:

1. **Zone** and **Wall** (e.g. WAREHOUSE 126 · west wall).
2. **Measured from**: which end of that wall you measured from (e.g. S end).
3. **Along the wall**: from that end to the nearest end of the unit.
4. **Out from wall**: gap between the wall and the back of the unit (0 = against it).

The preview shows the resulting X, Y and rotation; **Move [shelf] here** saves it and records a wall reference
like "WAREHOUSE 126 west wall, 20'-3" from S end, against the wall". **New unit here** places a new unit there at
the last-used size.

### When a real measurement differs from the plan

The building (rooms, walls, doors) was read off sheet A-1 and is seeded **unverified** (dashed amber outlines). When
the tape disagrees:

1. Switch to the **admin** role, **Edit** mode, **Plan** view.
2. Click the room (or the door / opening) on the plan or in the Layout list.
3. Drag its gold corner handles, or type the exact corners / ends in the inspector (survey-sheet toggle works here).
   Wall height and which edges have no wall are there too.
4. Tick **Verified on site with a tape**. The outline turns solid. Re-running the seed never overwrites a verified row.

### Roles

| Role | On the map |
|---|---|
| viewer | search, view, walk, read-only front view |
| editor | everything in Edit mode except rooms and openings |
| admin | also rooms, openings, verified flags, Overwrite on conflict, snapshot import |

### Snapshots

**⋯ → Export layout snapshot** downloads the whole layout as JSON. **Import snapshot** (admin, with a confirm)
replays rooms, openings, shelves and slots through the API, so every change is recorded and validated. Part
locations are not imported.

### Code map (`src/map/`)

| File | What it does |
|---|---|
| `App.tsx`, `main.tsx` | page shell, panels, shortcuts, deep links (`?shelf=&slot=&part=`), offline retry |
| `store.ts`, `actions.ts` | Zustand state; every API write (optimistic + rollback, conflicts, failed-edit queue, undo via the API's event undo) |
| `layoutOps.ts` | patches the cached layout after each write (no full refetch) |
| `geometry.ts` | walls, place-from-wall, snapping, warnings, aisle width, walk collision, fit check |
| `search.ts` | search → zoom level (floor / shelf / slot / none) |
| `scene/` | three.js via react-three-fiber: building, instanced shelves and bins, cameras, walk, plan grid, HTML labels, search glow |
| `ui/` | top bar, Layout / Parts panels, inspector, front-view editor, part card, dialogs, overlays |

Performance: shelves, decks, bins and pick boxes are `InstancedMesh`es (68 draw calls for 300 shelves /
5,087 slots); the layout loads once (ETag) and is patched locally after each edit; the canvas renders on
demand and only animates continuously while walking or while search dots pulse.
