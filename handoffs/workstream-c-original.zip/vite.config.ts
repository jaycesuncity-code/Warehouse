/// <reference types="vitest/config" />
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "node:path";

// One Vite multi-page build = one Cloudflare Pages project.
export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
    chunkSizeWarningLimit: 1500,
    rollupOptions: {
      input: {
        home: resolve(__dirname, "index.html"),
        warehouse: resolve(__dirname, "warehouse/index.html"),
        employee: resolve(__dirname, "employee/index.html"),
        map: resolve(__dirname, "map/index.html"),
      },
    },
  },
  test: {
    environment: "node",
    include: ["src/**/*.test.ts", "src/**/*.test.tsx"],
  },
});
